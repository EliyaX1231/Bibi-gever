# Bibi / Machal interactive page

A responsive Hebrew RTL landing page featuring the supplied image, a stylized Likud/Machal ballot, and a YouTube player that starts after the visitor clicks the image.

## Run locally
Open `index.html` in a browser. For best results, serve the folder with any static web server.

## Publish with GitHub Pages
1. Upload all files and the `assets` folder to a GitHub repository.
2. Open **Settings → Pages**.
3. Under **Build and deployment**, choose **Deploy from a branch**, select `main` and `/ (root)`, then save.

The YouTube player needs an internet connection. Some browsers or networks may restrict embedded playback; the page also includes a direct YouTube link.
