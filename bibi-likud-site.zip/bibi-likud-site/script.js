const portraitButton = document.getElementById('portraitButton');
const playerPanel = document.getElementById('playerPanel');
const youtubeFrame = document.getElementById('youtubeFrame');
const closePlayer = document.getElementById('closePlayer');
const clickHint = document.getElementById('clickHint');
const videoId = 'Pspva51y9PQ';

function playSound() {
  playerPanel.hidden = false;
  youtubeFrame.src = `https://www.youtube-nocookie.com/embed/${videoId}?autoplay=1&playsinline=1&rel=0`;
  portraitButton.classList.add('is-playing');
  clickHint.textContent = 'הנגן נפתח למטה';
  playerPanel.scrollIntoView({ behavior: 'smooth', block: 'nearest' });
}
function stopSound() {
  youtubeFrame.src = '';
  playerPanel.hidden = true;
  portraitButton.classList.remove('is-playing');
  clickHint.textContent = 'לחצו להפעלה';
}
portraitButton.addEventListener('click', playSound);
closePlayer.addEventListener('click', stopSound);
document.getElementById('year').textContent = new Date().getFullYear();
